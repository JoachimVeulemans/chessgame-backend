﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChessBackend.Services.ChessGame.Src.Enums
{
    public enum Color
    {
        BLACK,
        WHITE
    }
}
