﻿using System;

namespace ChessBackend.Services
{
    public class Class1
    {
    }
}
